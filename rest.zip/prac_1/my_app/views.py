from django.shortcuts import render
from rest_framework import generics
from .models import Info
from .serializers import Name_Serializers

# Create your views here.

class Name_List(generics.ListAPIView):
    queryset = Info.objects.all()
    serializer_class = Name_Serializers

class Name_Detail(generics.RetrieveAPIView):
    queryset = Info.objects.all()
    serializer_class = Name_Serializers
